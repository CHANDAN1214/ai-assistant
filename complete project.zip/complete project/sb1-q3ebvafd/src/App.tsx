import React, { useState } from 'react';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import JobCard from './components/JobCard';
import ResumeBuilder from './components/ResumeBuilder';
import CareerInsights from './components/CareerInsights';
import type { Job, SearchFilters } from './types';
import { Sparkles } from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('smart-search');
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    location: '',
    experience: '',
    company: '',
    salary: '',
  });

  const [showResume, setShowResume] = useState(false);
  const [isAISearching, setIsAISearching] = useState(false);
  const [aiResults, setAiResults] = useState<string | null>(null);
  const [jobs, setJobs] = useState<Job[]>([
    {
      id: '1',
      title: 'AI/ML Engineer',
      company: 'TechCorp Solutions',
      location: 'Bangalore',
      experience: '3-5 years',
      salary: '25-35 LPA',
      description: 'Join our AI team to develop cutting-edge machine learning solutions for enterprise clients. Work with the latest AI technologies and frameworks.',
      skills: ['Python', 'TensorFlow', 'PyTorch', 'NLP'],
      requirements: ['Experience with deep learning', 'Strong Python skills', 'ML model deployment', 'Cloud platforms'],
      postedAt: '2 days ago',
      matchScore: 95,
    },
    {
      id: '2',
      title: 'Full Stack AI Developer',
      company: 'Digital Innovations',
      location: 'Mumbai',
      experience: '2-4 years',
      salary: '18-25 LPA',
      description: 'Looking for a developer who can integrate AI/ML models into web applications. Experience with React and Python required.',
      skills: ['React', 'Python', 'FastAPI', 'Machine Learning'],
      requirements: ['Full-stack development', 'AI integration experience', 'RESTful APIs', 'Database design'],
      postedAt: '1 day ago',
      matchScore: 88,
    },
    {
      id: '3',
      title: 'AI Research Engineer',
      company: 'Cloud Systems Inc',
      location: 'Hyderabad',
      experience: '4-6 years',
      salary: '30-45 LPA',
      description: 'Research and develop new AI algorithms for cloud-based applications. PhD in Machine Learning or related field preferred.',
      skills: ['Deep Learning', 'Research', 'Python', 'Computer Vision'],
      requirements: ['PhD preferred', 'Research experience', 'Publication record', 'Algorithm development'],
      postedAt: '3 days ago',
      matchScore: 92,
    },
  ]);

  const calculateMatchScore = (job: Job, searchQuery: string): number => {
    const queryTerms = searchQuery.toLowerCase().split(' ');
    let score = 0;
    
    // Calculate skill match
    const skillMatch = job.skills.filter(skill => 
      queryTerms.some(term => skill.toLowerCase().includes(term))
    ).length;
    score += (skillMatch / job.skills.length) * 40; // Skills worth 40%

    // Calculate requirements match
    const reqMatch = job.requirements.filter(req =>
      queryTerms.some(term => req.toLowerCase().includes(term))
    ).length;
    score += (reqMatch / job.requirements.length) * 30; // Requirements worth 30%

    // Calculate title and description match
    const titleMatch = queryTerms.some(term => 
      job.title.toLowerCase().includes(term)
    );
    score += titleMatch ? 20 : 0; // Title match worth 20%

    const descMatch = queryTerms.some(term =>
      job.description.toLowerCase().includes(term)
    );
    score += descMatch ? 10 : 0; // Description match worth 10%

    return Math.round(score);
  };

  const handleAISearch = async (prompt: string) => {
    setIsAISearching(true);
    setAiResults(null);

    // Simulate AI processing and update match scores
    setTimeout(() => {
      const updatedJobs = jobs.map(job => ({
        ...job,
        matchScore: calculateMatchScore(job, prompt)
      }));

      // Sort jobs by match score
      updatedJobs.sort((a, b) => b.matchScore - a.matchScore);
      
      setJobs(updatedJobs);
      setIsAISearching(false);
      setAiResults(`Based on your search for "${prompt}", I've analyzed and ranked jobs based on skill match, requirements, and relevance. Jobs are sorted by match percentage.`);
    }, 1500);
  };

  // Filter jobs based on search criteria
  const filteredJobs = jobs.filter(job => {
    const matchesQuery = !filters.query || 
      job.title.toLowerCase().includes(filters.query.toLowerCase()) ||
      job.company.toLowerCase().includes(filters.query.toLowerCase()) ||
      job.skills.some(skill => skill.toLowerCase().includes(filters.query.toLowerCase()));
    
    const matchesLocation = !filters.location ||
      job.location.toLowerCase().includes(filters.location.toLowerCase());
    
    const matchesExperience = !filters.experience ||
      job.experience.includes(filters.experience);

    const matchesCompany = !filters.company ||
      job.company.toLowerCase().includes(filters.company.toLowerCase());

    const matchesSalary = !filters.salary ||
      job.salary.includes(filters.salary);

    return matchesQuery && matchesLocation && matchesExperience && matchesCompany && matchesSalary;
  });

  const renderContent = () => {
    if (showResume) {
      return <ResumeBuilder />;
    }

    switch (activeSection) {
      case 'career-insights':
        return <CareerInsights />;
      case 'smart-search':
      case 'ai-match':
      default:
        return (
          <>
            <SearchBar filters={filters} setFilters={setFilters} onAISearch={handleAISearch} />
            
            {isAISearching && (
              <div className="flex items-center justify-center py-12">
                <Sparkles className="h-8 w-8 text-blue-600 animate-pulse" />
                <span className="ml-3 text-lg text-gray-600">AI is analyzing job matches...</span>
              </div>
            )}

            {aiResults && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex items-start">
                  <Sparkles className="h-5 w-5 text-blue-600 mt-1 mr-2" />
                  <p className="text-blue-800">{aiResults}</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 gap-6">
              {filteredJobs.map(job => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>

            {filteredJobs.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">
                  No jobs found matching your criteria
                </p>
              </div>
            )}
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onNavChange={setActiveSection} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {activeSection === 'career-insights' ? 'Career Insights' : 'AI-Powered Job Search'}
              </h1>
              <p className="text-gray-600">
                {activeSection === 'career-insights' 
                  ? 'Explore market trends and growth opportunities'
                  : 'Let AI find your perfect job match'}
              </p>
            </div>
            {activeSection !== 'career-insights' && (
              <button
                onClick={() => setShowResume(!showResume)}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                {showResume ? 'Browse Jobs' : 'Build Resume'}
              </button>
            )}
          </div>
        </div>

        {renderContent()}
      </main>
    </div>
  );
}

export default App;