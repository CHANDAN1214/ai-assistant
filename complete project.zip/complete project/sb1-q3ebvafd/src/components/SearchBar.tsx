import React, { useState } from 'react';
import { Search, MapPin, Building2, Briefcase, Sparkles } from 'lucide-react';

interface SearchBarProps {
  filters: {
    query: string;
    location: string;
    experience: string;
    company: string;
    salary: string;
  };
  setFilters: (filters: any) => void;
  onAISearch: (prompt: string) => void;
}

export default function SearchBar({ filters, setFilters, onAISearch }: SearchBarProps) {
  const [aiPrompt, setAiPrompt] = useState('');
  const salaryRanges = [
    "0-5 LPA",
    "5-10 LPA",
    "10-15 LPA",
    "15-25 LPA",
    "25+ LPA"
  ];

  const handleAISearch = () => {
    if (aiPrompt.trim()) {
      onAISearch(aiPrompt);
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Search Section */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-6 rounded-lg shadow-md">
        <div className="flex flex-col space-y-4">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-6 w-6 text-white" />
            <h3 className="text-lg font-semibold text-white">AI-Powered Job Search</h3>
          </div>
          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="Describe your ideal job (e.g., 'Remote React developer position with AI focus')"
              className="flex-1 p-3 rounded-lg border-0 focus:ring-2 focus:ring-white"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
            />
            <button
              onClick={handleAISearch}
              className="px-6 py-3 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-semibold"
            >
              AI Search
            </button>
          </div>
        </div>
      </div>

      {/* Traditional Search Filters */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search jobs, skills, or keywords"
                className="pl-10 w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.query}
                onChange={(e) => setFilters({ ...filters, query: e.target.value })}
              />
            </div>
            
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Location (e.g., Mumbai, Delhi, Remote)"
                className="pl-10 w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.location}
                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Building2 className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Company name"
                className="pl-10 w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.company}
                onChange={(e) => setFilters({ ...filters, company: e.target.value })}
              />
            </div>

            <div>
              <select
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.experience}
                onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
              >
                <option value="">Experience Level</option>
                <option value="0-2">0-2 years</option>
                <option value="3-5">3-5 years</option>
                <option value="5-8">5-8 years</option>
                <option value="8-12">8-12 years</option>
                <option value="12+">12+ years</option>
              </select>
            </div>

            <div>
              <select
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.salary}
                onChange={(e) => setFilters({ ...filters, salary: e.target.value })}
              >
                <option value="">Salary Range</option>
                {salaryRanges.map((range) => (
                  <option key={range} value={range}>{range}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}