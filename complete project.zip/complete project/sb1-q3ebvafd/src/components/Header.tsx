import React, { useState } from 'react';
import { Search, BrainCircuit, UserCircle, Bell, LogIn, LineChart, Briefcase, Sparkles } from 'lucide-react';
import LoginModal from './LoginModal';
import ProfileDropdown from './ProfileDropdown';

export default function Header({ onNavChange }: { onNavChange: (section: string) => void }) {
  const [showLogin, setShowLogin] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <BrainCircuit className="h-8 w-8 text-white" />
            <span className="ml-2 text-2xl font-bold text-white">AI Job Match</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <button 
              onClick={() => onNavChange('smart-search')}
              className="flex items-center text-white hover:text-blue-200 transition-colors"
            >
              <Search className="h-4 w-4 mr-2" />
              Smart Search
            </button>
            <button 
              onClick={() => onNavChange('ai-match')}
              className="flex items-center text-white hover:text-blue-200 transition-colors"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              AI Match
            </button>
            <button 
              onClick={() => onNavChange('career-insights')}
              className="flex items-center text-white hover:text-blue-200 transition-colors"
            >
              <LineChart className="h-4 w-4 mr-2" />
              Career Insights
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            {isLoggedIn ? (
              <>
                <Bell className="h-6 w-6 text-white cursor-pointer" />
                <ProfileDropdown setIsLoggedIn={setIsLoggedIn} />
              </>
            ) : (
              <button
                onClick={() => setShowLogin(true)}
                className="flex items-center space-x-2 px-4 py-2 rounded-md bg-white text-blue-600 hover:bg-blue-50 transition-colors"
              >
                <LogIn className="h-5 w-5" />
                <span>Login</span>
              </button>
            )}
          </div>
        </div>
      </div>
      
      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onLogin={() => {
            setIsLoggedIn(true);
            setShowLogin(false);
          }}
        />
      )}
    </header>
  );
}