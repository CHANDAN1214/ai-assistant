import React from 'react';
import { Building2, MapPin, Clock, Briefcase, Sparkles, CheckCircle } from 'lucide-react';
import type { Job } from '../types';

export default function JobCard({ job }: { job: Job }) {
  const getMatchColor = (score: number) => {
    if (score >= 90) return 'bg-green-50 text-green-600';
    if (score >= 70) return 'bg-blue-50 text-blue-600';
    return 'bg-gray-50 text-gray-600';
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
          <div className="flex items-center mt-2 text-gray-600">
            <Building2 className="h-4 w-4 mr-2" />
            <span>{job.company}</span>
          </div>
        </div>
        <div className={`flex items-center px-3 py-1 rounded-full ${getMatchColor(job.matchScore)}`}>
          <Sparkles className="h-4 w-4 mr-1" />
          <span className="font-medium">{job.matchScore}% Match</span>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="flex items-center text-gray-600">
          <MapPin className="h-4 w-4 mr-2" />
          <span>{job.location}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Briefcase className="h-4 w-4 mr-2" />
          <span>{job.experience}</span>
        </div>
      </div>

      <div className="mt-4">
        <div className="text-gray-600">
          <span className="font-medium">₹</span> {job.salary}
        </div>
      </div>

      <p className="mt-4 text-gray-600">{job.description}</p>

      <div className="mt-4">
        <h4 className="font-medium text-gray-700 mb-2">Key Requirements:</h4>
        <div className="space-y-2">
          {job.requirements.map((req, index) => (
            <div key={index} className="flex items-start">
              <CheckCircle className="h-4 w-4 text-green-500 mt-1 mr-2" />
              <span className="text-gray-600">{req}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <h4 className="font-medium text-gray-700 mb-2">Skills:</h4>
        <div className="flex flex-wrap gap-2">
          {job.skills.map((skill, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="flex items-center text-gray-500">
          <Clock className="h-4 w-4 mr-1" />
          <span className="text-sm">{job.postedAt}</span>
        </div>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
          Apply Now
        </button>
      </div>
    </div>
  );
}