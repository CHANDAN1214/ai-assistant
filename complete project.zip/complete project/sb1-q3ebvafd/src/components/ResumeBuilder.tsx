import React, { useState, useRef } from 'react';
import { Plus, Trash2, Upload, FileText, CheckCircle } from 'lucide-react';

export default function ResumeBuilder() {
  const [resume, setResume] = useState({
    education: '',
    experience: [''],
    skills: [''],
    projects: [''],
  });

  const [uploadedResume, setUploadedResume] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addField = (field: 'experience' | 'skills' | 'projects') => {
    setResume({
      ...resume,
      [field]: [...resume[field], ''],
    });
  };

  const removeField = (field: 'experience' | 'skills' | 'projects', index: number) => {
    setResume({
      ...resume,
      [field]: resume[field].filter((_, i) => i !== index),
    });
  };

  const updateField = (
    field: 'experience' | 'skills' | 'projects',
    index: number,
    value: string
  ) => {
    const newArray = [...resume[field]];
    newArray[index] = value;
    setResume({
      ...resume,
      [field]: newArray,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && (file.type === 'application/pdf' || file.type === 'application/msword' || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')) {
      setUploadedResume(file);
    } else {
      alert('Please upload a PDF or Word document');
    }
  };

  return (
    <div className="space-y-6">
      {/* Resume Upload Section */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-2xl font-bold mb-4">Upload Your Resume</h2>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
          <div className="flex flex-col items-center">
            {uploadedResume ? (
              <div className="flex items-center space-x-2 text-green-600">
                <CheckCircle className="h-8 w-8" />
                <span className="text-lg">{uploadedResume.name}</span>
              </div>
            ) : (
              <>
                <Upload className="h-12 w-12 text-gray-400 mb-2" />
                <p className="text-gray-600 text-center mb-2">
                  Drag and drop your resume here, or click to select
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  Supported formats: PDF, DOC, DOCX
                </p>
              </>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".pdf,.doc,.docx"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              {uploadedResume ? 'Replace Resume' : 'Select File'}
            </button>
          </div>
        </div>
      </div>

      {/* Resume Builder Form */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-6">Or Build Your Resume</h2>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Education
            </label>
            <textarea
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              rows={4}
              value={resume.education}
              onChange={(e) => setResume({ ...resume, education: e.target.value })}
              placeholder="Enter your educational background..."
            />
          </div>

          {['experience', 'skills', 'projects'].map((field) => (
            <div key={field}>
              <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
                {field}
              </label>
              {resume[field as keyof typeof resume].map((item: string, index: number) => (
                <div key={index} className="flex mb-2">
                  <input
                    type="text"
                    className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value={item}
                    onChange={(e) =>
                      updateField(field as 'experience' | 'skills' | 'projects', index, e.target.value)
                    }
                    placeholder={`Enter ${field}...`}
                  />
                  <button
                    onClick={() =>
                      removeField(field as 'experience' | 'skills' | 'projects', index)
                    }
                    className="ml-2 text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              ))}
              <button
                onClick={() => addField(field as 'experience' | 'skills' | 'projects')}
                className="flex items-center text-blue-600 hover:text-blue-800"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add {field}
              </button>
            </div>
          ))}

          <button
            className="w-full bg-blue-600 text-white rounded-md py-2 hover:bg-blue-700 transition-colors"
            onClick={() => {
              // In a real app, save resume data here
              alert('Resume saved successfully!');
            }}
          >
            Save Resume
          </button>
        </div>
      </div>
    </div>
  );
}