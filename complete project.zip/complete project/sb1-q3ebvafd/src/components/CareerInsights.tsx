import React from 'react';
import { LineChart as Chart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Briefcase, TrendingUp, Users, GraduationCap } from 'lucide-react';

const salaryTrends = [
  { year: '2020', junior: 5, mid: 12, senior: 25 },
  { year: '2021', junior: 6, mid: 15, senior: 30 },
  { year: '2022', junior: 8, mid: 18, senior: 35 },
  { year: '2023', junior: 10, mid: 22, senior: 40 },
  { year: '2024', junior: 12, mid: 25, senior: 45 },
];

const skillDemand = [
  { skill: 'AI/ML', demand: 95 },
  { skill: 'React', demand: 88 },
  { skill: 'Python', demand: 85 },
  { skill: 'Cloud', demand: 82 },
  { skill: 'DevOps', demand: 78 },
];

export default function CareerInsights() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-3 rounded-full">
              <Briefcase className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Open Positions</p>
              <p className="text-2xl font-bold">2,547</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <div className="bg-green-100 p-3 rounded-full">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Avg. Salary Growth</p>
              <p className="text-2xl font-bold">15.8%</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <div className="bg-purple-100 p-3 rounded-full">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Hiring Companies</p>
              <p className="text-2xl font-bold">834</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <div className="bg-orange-100 p-3 rounded-full">
              <GraduationCap className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Required Skills</p>
              <p className="text-2xl font-bold">12+</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-4">Salary Trends (in LPA)</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <Chart data={salaryTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="junior" stroke="#3B82F6" name="Junior" />
                <Line type="monotone" dataKey="mid" stroke="#10B981" name="Mid-Level" />
                <Line type="monotone" dataKey="senior" stroke="#8B5CF6" name="Senior" />
              </Chart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-4">Top Skills in Demand (%)</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={skillDemand}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="skill" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="demand" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">Career Growth Tips</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Skill Development</h4>
            <p className="text-blue-600">Focus on emerging technologies like AI/ML, Cloud Computing, and Full-Stack Development.</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <h4 className="font-medium text-green-800 mb-2">Industry Certifications</h4>
            <p className="text-green-600">Obtain relevant certifications in your domain to stand out in the job market.</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <h4 className="font-medium text-purple-800 mb-2">Networking</h4>
            <p className="text-purple-600">Build professional connections through industry events and online platforms.</p>
          </div>
        </div>
      </div>
    </div>
  );
}