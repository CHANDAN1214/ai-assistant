import React, { useState } from 'react';
import { UserCircle, FileText, LogOut } from 'lucide-react';

interface ProfileDropdownProps {
  setIsLoggedIn: (value: boolean) => void;
}

export default function ProfileDropdown({ setIsLoggedIn }: ProfileDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2"
      >
        <UserCircle className="h-8 w-8 text-gray-600" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
          <a
            href="#"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
          >
            <UserCircle className="h-4 w-4 mr-2" />
            Profile
          </a>
          <a
            href="#"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
          >
            <FileText className="h-4 w-4 mr-2" />
            My Resume
          </a>
          <button
            onClick={() => setIsLoggedIn(false)}
            className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </button>
        </div>
      )}
    </div>
  );
}