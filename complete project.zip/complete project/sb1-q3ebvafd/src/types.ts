export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  experience: string;
  salary: string;
  description: string;
  skills: string[];
  requirements: string[];
  postedAt: string;
  matchScore: number;
}

export interface SearchFilters {
  query: string;
  location: string;
  experience: string;
  company: string;
  salary: string;
}

export interface User {
  name: string;
  email: string;
  resume?: {
    education: string;
    experience: string[];
    skills: string[];
    projects: string[];
  };
}